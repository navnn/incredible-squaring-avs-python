#pragma once
#ifndef assert
	#define assert(x)
#endif
